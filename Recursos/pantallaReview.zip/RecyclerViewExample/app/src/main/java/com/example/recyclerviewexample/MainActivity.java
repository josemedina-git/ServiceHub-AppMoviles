package com.example.recyclerviewexample;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private RecyclerViewAdapter adapter;
    private List<Item> itemList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa el RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this)); // Usa un LinearLayoutManager para listas verticales

        // Inicializa los datos
        itemList = new ArrayList<>();
        itemList.add(new Item("Cleotilde González", "Excelente servicio", "17h", R.drawable.user1));
        itemList.add(new Item("Vannevar Bush", "Excelente servicio", "5d", R.drawable.user2));
        itemList.add(new Item("Antonieta de las Nieves", "Excelente servicio", "17w", R.drawable.user3));
        // Agrega más elementos si es necesario

        // Inicializa el Adapter y asignarlo al RecyclerView
        adapter = new RecyclerViewAdapter(itemList);
        recyclerView.setAdapter(adapter);
    }
}
