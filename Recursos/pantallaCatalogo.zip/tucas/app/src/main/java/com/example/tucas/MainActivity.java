package com.example.tucas;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;
import com.google.android.material.bottomnavigation.BottomNavigationView;


public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ServiceAdapter serviceAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pantalla_catalog);

        // Configuración del RecyclerView
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // Lista de datos simulados
        List<Service> serviceList = new ArrayList<>();
        serviceList.add(new Service("Plumbing", "Emily Thompson", 5.0));
        serviceList.add(new Service("Plumbing", "Michael Johnson", 4.9));
        serviceList.add(new Service("Plumbing", "Sarah Carter", 4.9));
        serviceList.add(new Service("Designer", "David Miller", 4.9));
        serviceList.add(new Service("Designer", "Jessica Roberts", 4.8));
        serviceList.add(new Service("Carpenter", "Daniel Wilson", 4.8));
        serviceList.add(new Service("Carpenter", "Ashley Turner", 4.5));
        serviceList.add(new Service("Moving", "James Baker", 4.5));

        // Configuración del adaptador
        serviceAdapter = new ServiceAdapter(serviceList);
        recyclerView.setAdapter(serviceAdapter);

        // Obtener referencia al BottomNavigationView
        BottomNavigationView bottomNavigationView = findViewById(R.id.bottomNavigation);

        // Establecer la opción seleccionada por defecto
        bottomNavigationView.setSelectedItemId(R.id.navigation_catalog);

        // Configurar el listener de navegación
        bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            if (item.getItemId() == R.id.navigation_home) {
                // Acción para "Home"
                return true;
            } else if (item.getItemId() == R.id.navigation_catalog) {
                // Acción para "Catalog"
                return true;
            } else if (item.getItemId() == R.id.navigation_me) {
                // Acción para "Me"
                return true;
            }
            return false;
        });
    }
}
